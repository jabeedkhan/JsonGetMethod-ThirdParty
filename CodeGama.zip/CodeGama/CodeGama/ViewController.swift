//
//  ViewController.swift
//  CodeGama
//
//  Created by jabeed on 22/11/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit
import Kingfisher


class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var arrData = [JsonModel]()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.jsonParsing()
        // Do any additional setup after loading the view.
    }
    

    
    func jsonParsing(){
        let url = URL(string: "http://staging.gentack.info/categories")
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            guard let data = data else { return }
            do{
                let response = try JSON(data:data)
                print(response)
                let dataDic = response["data"]
                print(dataDic)
                for arr in dataDic.arrayValue{
                    self.arrData.append(JsonModel(json: arr))
                    
                }
            }catch{
                print(error.localizedDescription)
            }
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            }.resume()
    }
    

}
extension ViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:TableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        cell.id.text = String(arrData[indexPath.row].category_id)
        cell.name.text = arrData[indexPath.row].category_name
        cell.descption.text = arrData[indexPath.row].category_description
        cell.img.kf.setImage(with: URL(string: arrData[indexPath.row].category_picture))
        return cell
    }
    
    
}
