//
//  JsonModel.swift
//  CodeGama
//
//  Created by jabeed on 22/11/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import Foundation
struct JsonModel{
    let category_id:Int
    let category_name:String
    let category_description:String
    let category_picture:String
    
    init(json:JSON) {
        category_id = json["category_id"].intValue
        category_name = json["category_name"].stringValue
        category_description = json["category_description"].stringValue
        category_picture = json["category_picture"].stringValue
        
    }
    
}


